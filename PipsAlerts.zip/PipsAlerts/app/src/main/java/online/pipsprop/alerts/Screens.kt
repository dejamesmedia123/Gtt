package online.pipsprop.alerts

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
private fun Pill(text: String, color: Color) {
    Text(
        text, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.background(color, RoundedCornerShape(99.dp)).padding(horizontal = 9.dp, vertical = 3.dp),
    )
}

// ============================== ALERTS TAB ==============================

@Composable
fun AlertsScreen() {
    val ctx = LocalContext.current
    val running = WatchService.running
    val fmt = remember { SimpleDateFormat("d MMM HH:mm", Locale.getDefault()) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("PipsProp Alerts", fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, modifier = Modifier.padding(top = 16.dp))
            Muted("Price alerts from three strategies, working in the background.")
        }
        item {
            PCard(border = if (running) Brand.Green else Brand.Border) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (running) "Watching" else "Not watching", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                    Pill(if (running) "ON" else "OFF", if (running) Brand.Green else Brand.Muted)
                }
                Muted(if (running) WatchService.status.ifBlank { "Watching " + Store.watch.size + " markets" } else if (Store.watch.isEmpty()) "Add markets on the Watch tab first." else Store.watch.size.toString() + " markets are set up. Tap Start to be alerted.", 13)
                if (running) {
                    DangerButton("Stop watching", Modifier.fillMaxWidth()) { WatchService.stop(ctx) }
                } else {
                    PrimaryButton("Start watching", Modifier.fillMaxWidth(), enabled = Store.watch.isNotEmpty()) {
                        Store.watching = true
                        Store.save()
                        WatchService.start(ctx)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SecondaryButton("Test alert", Modifier.weight(1f)) { Alerts.test(ctx, false) }
                SecondaryButton("Test urgent", Modifier.weight(1f)) { Alerts.test(ctx, true) }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                H("Recent alerts")
                Text("", Modifier.weight(1f))
                if (Store.history.isNotEmpty()) TextButton(onClick = { Store.clearHistory() }) { Text("Clear") }
            }
        }
        if (Store.history.isEmpty()) {
            item { Muted("No alerts yet. They appear here as they arrive.", 13) }
        }
        items(Store.history) { r ->
            PCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(r.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    if (r.mode == 2) Pill("URGENT", Brand.Red)
                    if (r.silent) Pill("QUIET", Brand.Amber)
                }
                Text(r.text, fontSize = 13.sp)
                Muted(fmt.format(Date(r.time)))
            }
        }
        item { Text("", Modifier.padding(bottom = 12.dp)) }
    }
}

// ============================== WATCH TAB ==============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WatchScreen() {
    val ctx = LocalContext.current
    var showPicker by remember { mutableStateOf(false) }
    var pick by remember { mutableStateOf<Market?>(null) }
    var tf by remember { mutableIntStateOf(900) }
    val running = WatchService.running

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Watch list", fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
        Muted("The markets the background watcher follows. Each one is checked by all three strategies.")

        if (Store.watch.isEmpty()) Muted("Nothing yet. Add a market below.", 13)
        for (w in Store.watch) {
            val m = marketByKey(w.key)
            PCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text((m?.name ?: w.key) + "  " + tfLabel(w.tf), fontWeight = FontWeight.Bold)
                        Muted(if (m?.src == 'b') "Binance" else "Deriv")
                    }
                    TextButton(onClick = { Store.watch = Store.watch.filter { it.id != w.id }; Store.save() }) { Text("Remove", color = Brand.Red) }
                }
            }
        }

        if (running) {
            PCard(border = Brand.Amber) {
                Muted("The watcher is running. Restart it to apply changes to the list.", 13)
                SecondaryButton("Restart watcher", Modifier.fillMaxWidth()) {
                    WatchService.stop(ctx)
                    Store.watching = true
                    Store.save()
                    WatchService.start(ctx)
                }
            }
        }

        H("Add a market")
        PCard {
            SecondaryButton(if (pick == null) "Choose a market" else pick!!.name + " (" + (if (pick!!.src == 'b') "Binance" else "Deriv") + ")", Modifier.fillMaxWidth()) { showPicker = true }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for ((g, label) in TIMEFRAMES) {
                    FilterChip(selected = tf == g, onClick = { tf = g }, label = { Text(label) })
                }
            }
            val p = pick
            val dup = p != null && Store.watch.any { it.key == p.key && it.tf == tf }
            PrimaryButton("Add to the watch list", Modifier.fillMaxWidth(), enabled = p != null && !dup && Store.watch.size < 8) {
                if (p != null) {
                    Store.watch = Store.watch + WatchItem(p.key, tf)
                    Store.save()
                    pick = null
                }
            }
            if (dup) Muted("That market and timeframe is already in the list.")
            if (Store.watch.size >= 8) Muted("Up to 8 markets keeps the battery and data use reasonable.")
        }
        Muted("Tip: closed-candle alerts need the candle to finish, so on 1h a signal can take up to an hour to appear. Use 5m or 15m for faster alerts.", 12)
    }

    if (showPicker) MarketPicker(onPick = { pick = it; showPicker = false }, onDismiss = { showPicker = false })
}

// ============================== SETTINGS TAB ==============================

private fun launchSettings(ctx: Context, intent: Intent) {
    try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not open that screen on this phone", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun PermRow(title: String, why: String, ok: Boolean, action: String, onAction: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Muted(why)
        }
        if (ok) Pill("ON", Brand.Green) else SecondaryButton(action, onClick = onAction)
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val pkg = ctx.packageName
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick += 1 }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick += 1 }
    val nm = ctx.getSystemService(NotificationManager::class.java)
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    val notifOk = tick >= 0 && (Build.VERSION.SDK_INT < 33 || ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
    val battOk = tick >= 0 && pm.isIgnoringBatteryOptimizations(pkg)
    val dndOk = tick >= 0 && nm.isNotificationPolicyAccessGranted
    val fullOk = tick >= 0 && (Build.VERSION.SDK_INT < 34 || nm.canUseFullScreenIntent())

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)

        H("Permissions")
        PCard {
            PermRow("Notifications", "Needed to show any alert.", notifOk, "Allow") {
                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            PermRow("Battery: unrestricted", "Stops Android from putting the watcher to sleep.", battOk, "Allow") {
                launchSettings(ctx, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$pkg")))
            }
            PermRow("Override Do Not Disturb", "Lets urgent alerts ring in silent mode.", dndOk, "Allow") {
                launchSettings(ctx, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
            PermRow("Full-screen alerts", "Lets urgent alerts light up the lock screen.", fullOk, "Allow") {
                if (Build.VERSION.SDK_INT >= 34) launchSettings(ctx, Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$pkg")))
            }
            Muted("Also set on your phone: open App info, then Battery, and choose Unrestricted. On Tecno, Infinix and Itel phones turn on Autostart and lock the app in the recent apps list. Without these, the phone may close the watcher.", 12)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SecondaryButton("App info", Modifier.weight(1f)) { launchSettings(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) }
                SecondaryButton("Urgent channel", Modifier.weight(1f)) {
                    Alerts.ensureChannels(ctx)
                    launchSettings(ctx, Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg).putExtra(Settings.EXTRA_CHANNEL_ID, Alerts.CH_URGENT))
                }
            }
        }

        H("Alert types")
        Muted("Choose how each alert behaves: Off, Normal (a notification) or Urgent (alarm sound, full screen, ignores Do Not Disturb).")
        var lastStrategy = ""
        for (k in AlertKind.values()) {
            if (k.strategy != lastStrategy) {
                lastStrategy = k.strategy
                Text(k.strategy, fontWeight = FontWeight.Bold, color = Brand.Blue, modifier = Modifier.padding(top = 6.dp))
            }
            PCard {
                Text(k.label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val cur = Store.modeOf(k)
                    listOf("Off", "Normal", "Urgent").forEachIndexed { i, name ->
                        FilterChip(selected = cur == i, onClick = { Store.setMode(k, i) }, label = { Text(name) })
                    }
                }
            }
        }

        H("Distances")
        PCard {
            DecField("Near a target: within this many R", Store.nearTargetR, Modifier.fillMaxWidth()) { Store.nearTargetR = it.coerceIn(0.05, 5.0); Store.save() }
            DecField("Near the trend line: within this many ATR", Store.nearLineAtr, Modifier.fillMaxWidth()) { Store.nearLineAtr = it.coerceIn(0.05, 5.0); Store.save() }
            DecField("Near the channel edge: within this many ATR", Store.nearEdgeAtr, Modifier.fillMaxWidth()) { Store.nearEdgeAtr = it.coerceIn(0.05, 5.0); Store.save() }
            DecField("Near support / resistance: within this many ATR", Store.nearStructAtr, Modifier.fillMaxWidth()) { Store.nearStructAtr = it.coerceIn(0.05, 5.0); Store.save() }
            IntField("Minutes between repeated \"near\" alerts", Store.cooldownMin, Modifier.fillMaxWidth()) { Store.cooldownMin = it.coerceIn(0, 1440); Store.save() }
            IntField("Isotropic block period", Store.isoPeriod, Modifier.fillMaxWidth()) { Store.isoPeriod = it.coerceIn(5, 100); Store.save() }
            Muted("R = the distance from entry to stop. ATR = the average candle range. Changes apply the next time the watcher starts.")
        }

        H("Quiet hours")
        PCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("No sound during quiet hours", Modifier.weight(1f), fontSize = 14.sp)
                Switch(checked = Store.quietOn, onCheckedChange = { Store.quietOn = it; Store.save() })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IntField("From (hour 0-23)", Store.quietFrom, Modifier.weight(1f)) { Store.quietFrom = it.coerceIn(0, 23); Store.save() }
                IntField("Until (hour 0-23)", Store.quietTo, Modifier.weight(1f)) { Store.quietTo = it.coerceIn(0, 23); Store.save() }
            }
            Muted("Normal alerts are held back and only listed in the Alerts tab. Urgent alerts still come through.")
        }

        H("About")
        PCard {
            Muted("Trend Target Ribbon is a Kotlin port of the Pine Script indicator \"Trend Target Ribbon [BOSWaves]\" by BOSWaves, used under the Mozilla Public License 2.0 (mozilla.org/MPL/2.0).", 12)
            Muted("Isotropic Trend Lines is an approximation written from the description of the \"Smart Trader, Episode 06\" script, so it can differ from the TradingView version.", 12)
            Muted("Market structure is ported from the PipsProp chart. Prices come from the public Deriv and Binance APIs.", 12)
            Muted("Alerts are for information only. They are not trading advice and the app does not place trades.", 12)
        }
        Text("", Modifier.padding(bottom = 12.dp))
    }
}
