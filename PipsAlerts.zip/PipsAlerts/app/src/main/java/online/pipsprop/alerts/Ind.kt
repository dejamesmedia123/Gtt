package online.pipsprop.alerts

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sqrt

/** Indicator maths shared by the strategies. Values that cannot be computed yet are NaN. */
object Ind {

    /** Average True Range, Wilder smoothing seeded with a simple average (the same as TradingView's ta.atr). */
    fun atr(c: List<Candle>, len: Int): DoubleArray {
        val n = c.size
        val out = DoubleArray(n) { Double.NaN }
        if (n < len || len < 1) return out
        val tr = DoubleArray(n)
        for (i in 0 until n) {
            tr[i] = if (i == 0) c[i].h - c[i].l else max(c[i].h - c[i].l, max(abs(c[i].h - c[i - 1].c), abs(c[i].l - c[i - 1].c)))
        }
        var sum = 0.0
        for (i in 0 until len) sum += tr[i]
        var prev = sum / len
        out[len - 1] = prev
        for (i in len until n) {
            prev = (prev * (len - 1) + tr[i]) / len
            out[i] = prev
        }
        return out
    }

    /** Arnaud Legoux moving average (the same weights as TradingView's ta.alma). */
    fun alma(src: DoubleArray, len: Int, offset: Double, sigma: Double): DoubleArray {
        val n = src.size
        val out = DoubleArray(n) { Double.NaN }
        if (n < len || len < 1) return out
        val m = floor(offset * (len - 1))
        val s = len / sigma
        val w = DoubleArray(len) { k -> exp(-((k - m) * (k - m)) / (2.0 * s * s)) }
        var norm = 0.0
        for (x in w) norm += x
        for (i in len - 1 until n) {
            var sum = 0.0
            for (k in 0 until len) sum += src[i - (len - 1) + k] * w[k]
            out[i] = sum / norm
        }
        return out
    }

    /** Standard deviation over a window (population form, like TradingView's ta.stdev). */
    fun stdev(src: DoubleArray, len: Int): DoubleArray {
        val n = src.size
        val out = DoubleArray(n) { Double.NaN }
        if (n < len || len < 1) return out
        for (i in len - 1 until n) {
            var mean = 0.0
            for (k in 0 until len) mean += src[i - k]
            mean /= len
            var v = 0.0
            for (k in 0 until len) {
                val d = src[i - k] - mean
                v += d * d
            }
            out[i] = sqrt(v / len)
        }
        return out
    }
}
