package online.pipsprop.alerts

import java.util.Locale

/** One candle. [t] is the start of the candle in seconds. */
data class Candle(val t: Long, val o: Double, val h: Double, val l: Double, val c: Double)

/** A market. [src] is 'd' for Deriv or 'b' for Binance. */
data class Market(val src: Char, val id: String, val dec: Int, val name: String, val grp: String) {
    val key: String get() = (if (src == 'b') "BINANCE:" else "DERIV:") + id
}

val MARKETS: List<Market> = listOf(
    Market('d', "frxXAUUSD", 2, "XAUUSD (gold)", "Metals"),
    Market('d', "cryBTCUSD", 2, "BTCUSD (Deriv)", "Crypto"),
    Market('d', "frxEURUSD", 5, "EURUSD", "Forex"),
    Market('d', "frxGBPUSD", 5, "GBPUSD", "Forex"),
    Market('d', "frxUSDJPY", 3, "USDJPY", "Forex"),
    Market('d', "frxAUDUSD", 5, "AUDUSD", "Forex"),
    Market('d', "frxUSDCAD", 5, "USDCAD", "Forex"),
    Market('d', "R_75", 4, "Volatility 75", "Synthetic indices"),
    Market('d', "R_100", 2, "Volatility 100", "Synthetic indices"),
    Market('b', "BTCUSDT", 2, "BTCUSDT", "Crypto"),
    Market('b', "ETHUSDT", 2, "ETHUSDT", "Crypto"),
    Market('b', "SOLUSDT", 3, "SOLUSDT", "Crypto"),
    Market('d', "frxAUDCAD", 5, "AUDCAD", "Forex"),
    Market('d', "frxAUDCHF", 5, "AUDCHF", "Forex"),
    Market('d', "frxAUDJPY", 3, "AUDJPY", "Forex"),
    Market('d', "frxAUDNZD", 5, "AUDNZD", "Forex"),
    Market('d', "frxEURAUD", 5, "EURAUD", "Forex"),
    Market('d', "frxEURCAD", 5, "EURCAD", "Forex"),
    Market('d', "frxEURCHF", 5, "EURCHF", "Forex"),
    Market('d', "frxEURGBP", 5, "EURGBP", "Forex"),
    Market('d', "frxEURJPY", 3, "EURJPY", "Forex"),
    Market('d', "frxGBPAUD", 5, "GBPAUD", "Forex"),
    Market('d', "frxGBPCAD", 5, "GBPCAD", "Forex"),
    Market('d', "frxGBPCHF", 5, "GBPCHF", "Forex"),
    Market('d', "frxGBPJPY", 3, "GBPJPY", "Forex"),
    Market('d', "frxNZDJPY", 3, "NZDJPY", "Forex"),
    Market('d', "frxNZDUSD", 5, "NZDUSD", "Forex"),
    Market('d', "frxUSDCHF", 5, "USDCHF", "Forex"),
    Market('d', "frxXAGUSD", 4, "XAGUSD (silver)", "Metals"),
    Market('d', "frxXPDUSD", 2, "XPDUSD (palladium)", "Metals"),
    Market('d', "frxXPTUSD", 2, "XPTUSD (platinum)", "Metals"),
    Market('d', "cryETHUSD", 2, "ETHUSD (Deriv)", "Crypto"),
    Market('d', "R_10", 3, "Volatility 10", "Synthetic indices"),
    Market('d', "R_25", 3, "Volatility 25", "Synthetic indices"),
    Market('d', "R_50", 4, "Volatility 50", "Synthetic indices"),
    Market('d', "1HZ10V", 2, "Volatility 10 (1s)", "Synthetic indices"),
    Market('d', "1HZ25V", 2, "Volatility 25 (1s)", "Synthetic indices"),
    Market('d', "1HZ50V", 2, "Volatility 50 (1s)", "Synthetic indices"),
    Market('d', "1HZ75V", 2, "Volatility 75 (1s)", "Synthetic indices"),
    Market('d', "1HZ100V", 2, "Volatility 100 (1s)", "Synthetic indices"),
    Market('d', "BOOM500", 3, "Boom 500", "Synthetic indices"),
    Market('d', "BOOM1000", 3, "Boom 1000", "Synthetic indices"),
    Market('d', "CRASH500", 3, "Crash 500", "Synthetic indices"),
    Market('d', "CRASH1000", 3, "Crash 1000", "Synthetic indices"),
    Market('d', "stpRNG", 2, "Step Index", "Synthetic indices"),
    Market('d', "OTC_NDX", 2, "US Tech 100", "Stock indices"),
    Market('d', "OTC_SPC", 2, "US 500", "Stock indices"),
    Market('d', "OTC_DJI", 2, "Wall Street 30", "Stock indices"),
    Market('d', "OTC_FTSE", 2, "UK 100", "Stock indices"),
    Market('d', "OTC_GDAXI", 2, "Germany 40", "Stock indices"),
    Market('d', "OTC_FCHI", 2, "France 40", "Stock indices"),
    Market('d', "OTC_N225", 2, "Japan 225", "Stock indices"),
    Market('b', "BNBUSDT", 2, "BNBUSDT", "Crypto"),
    Market('b', "XRPUSDT", 4, "XRPUSDT", "Crypto"),
    Market('b', "ADAUSDT", 4, "ADAUSDT", "Crypto"),
    Market('b', "DOGEUSDT", 5, "DOGEUSDT", "Crypto"),
    Market('b', "AVAXUSDT", 3, "AVAXUSDT", "Crypto"),
    Market('b', "LINKUSDT", 3, "LINKUSDT", "Crypto"),
    Market('b', "LTCUSDT", 2, "LTCUSDT", "Crypto"),
    Market('b', "TRXUSDT", 5, "TRXUSDT", "Crypto"),
    Market('b', "DOTUSDT", 3, "DOTUSDT", "Crypto")
)

fun marketByKey(key: String): Market? = MARKETS.firstOrNull { it.key == key }

val TIMEFRAMES: List<Pair<Int, String>> = listOf(60 to "1m", 300 to "5m", 900 to "15m", 1800 to "30m", 3600 to "1h", 14400 to "4h", 86400 to "1d")
fun tfLabel(g: Int): String = TIMEFRAMES.firstOrNull { it.first == g }?.second ?: (g.toString() + "s")

/** One market + timeframe the app watches in the background. */
data class WatchItem(val key: String, val tf: Int) {
    val id: String get() = "$key|$tf"
}

/** How loud an alert type is: 0 off, 1 normal, 2 urgent (loud, full screen, ignores Do Not Disturb). */
enum class AlertKind(val label: String, val strategy: String, val defaultMode: Int) {
    RIBBON_SIGNAL("New long / short signal", "Trend Target Ribbon", 1),
    RIBBON_TARGET("Target hit", "Trend Target Ribbon", 1),
    RIBBON_STOP("Stop hit", "Trend Target Ribbon", 2),
    RIBBON_NEAR_TARGET("Price near a target", "Trend Target Ribbon", 1),
    RIBBON_NEAR_LINE("Price near the trend line", "Trend Target Ribbon", 1),
    ISO_BREAKOUT("Channel breakout", "Isotropic Trend Lines", 1),
    ISO_RETEST("Retest of the broken line", "Isotropic Trend Lines", 1),
    ISO_FAILED("Failed breakout", "Isotropic Trend Lines", 1),
    ISO_DIRECTION("Trend direction changed", "Isotropic Trend Lines", 0),
    ISO_NEAR_EDGE("Price near the channel edge", "Isotropic Trend Lines", 1),
    STX_NEAR("Price near support / resistance", "Market structure", 1),
    STX_BROKEN("Support / resistance broken", "Market structure", 1),
    STX_AREA_EXIT("Price left the range", "Market structure", 1),
}

fun fp(v: Double, dec: Int): String = String.format(Locale.US, "%." + dec + "f", v)
