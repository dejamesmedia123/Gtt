package online.pipsprop.alerts

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Brand {
    val Blue = Color(0xFF0000FF)
    val Green = Color(0xFF00C853)
    val GreenDark = Color(0xFF00963C)
    val Red = Color(0xFFFF3333)
    val Amber = Color(0xFFF59E0B)
    val Muted = Color(0xFF667085)
    val Border = Color(0xFFE5E7EB)
    val Surface = Color(0xFFF7F8FA)
    val Surface2 = Color(0xFFF0F2F5)
    val Text = Color(0xFF111827)
}

@Composable
fun PCard(modifier: Modifier = Modifier, border: Color = Brand.Border, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, border),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
fun H(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Brand.Text, modifier = Modifier.padding(top = 6.dp))
}

@Composable
fun Muted(text: String, size: Int = 12) {
    Text(text, color = Brand.Muted, fontSize = size.sp)
}

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier, shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Brand.Blue, contentColor = Color.White),
    ) { Text(text, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun SecondaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick, enabled = enabled, modifier = modifier, shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Brand.Border),
    ) { Text(text, color = if (enabled) Brand.Text else Brand.Muted, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun DangerButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick, modifier = modifier, shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Brand.Red, contentColor = Color.White),
    ) { Text(text, fontWeight = FontWeight.SemiBold) }
}

/** A number box that accepts decimals. */
@Composable
fun DecField(label: String, value: Double, modifier: Modifier = Modifier, onChange: (Double) -> Unit) {
    var text by remember { mutableStateOf(if (value % 1.0 == 0.0) value.toInt().toString() else value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = { t ->
            val clean = t.replace(',', '.').filter { it.isDigit() || it == '.' }.take(7)
            text = clean
            clean.toDoubleOrNull()?.let(onChange)
        },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier,
    )
}

@Composable
fun IntField(label: String, value: Int, modifier: Modifier = Modifier, onChange: (Int) -> Unit) {
    var text by remember { mutableStateOf(value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = { t ->
            val clean = t.filter { it.isDigit() }.take(4)
            text = clean
            clean.toIntOrNull()?.let(onChange)
        },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier,
    )
}

private val GROUP_ORDER = listOf("Forex", "Metals", "Crypto", "Stock indices", "Synthetic indices")

/** A list of every market, grouped, to pick one from. */
@Composable
fun MarketPicker(onPick: (Market) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose a market") },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                for (g in GROUP_ORDER) {
                    val list = MARKETS.filter { it.grp == g }
                    if (list.isEmpty()) continue
                    item {
                        Text(g, fontWeight = FontWeight.Bold, color = Brand.Blue, modifier = Modifier.padding(top = 10.dp, bottom = 2.dp))
                    }
                    items(list) { m ->
                        Text(
                            m.name + (if (m.src == 'b') "  (Binance)" else "  (Deriv)"),
                            modifier = Modifier.fillMaxWidth().clickable { onPick(m) }.padding(vertical = 10.dp),
                            fontSize = 15.sp,
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}
