package online.pipsprop.alerts

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** The always-on watcher: a foreground service with a permanent notification, so Android keeps it running. */
class WatchService : Service() {

    companion object {
        var running by mutableStateOf(false)
        var status by mutableStateOf("")
        const val ACTION_STOP = "online.pipsprop.alerts.STOP"
        private const val NOTIF_ID = 1

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WatchService::class.java))
        }

        fun stop(ctx: Context) {
            Store.init(ctx)
            Store.watching = false
            Store.save()
            ctx.stopService(Intent(ctx, WatchService::class.java))
        }
    }

    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Store.init(this)
        if (intent?.action == ACTION_STOP) {
            Store.watching = false
            Store.save()
            stopSelf()
            return START_NOT_STICKY
        }
        Alerts.ensureChannels(this)
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, build("Starting..."), type)
        running = true
        Store.watching = true
        Store.save()
        if (wake == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "pipsprop:watch")
            wake?.acquire()
        }
        Watcher.start(applicationContext) { s ->
            status = s
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, build(s))
        }
        return START_STICKY
    }

    private fun build(text: String): Notification {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), flags)
        val stop = PendingIntent.getService(this, 2, Intent(this, WatchService::class.java).setAction(ACTION_STOP), flags)
        return NotificationCompat.Builder(this, Alerts.CH_WATCH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("PipsProp Alerts is watching")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Stop watching", stop)
            .build()
    }

    override fun onDestroy() {
        Watcher.stop()
        try {
            wake?.release()
        } catch (e: Exception) {
            // already released
        }
        wake = null
        running = false
        super.onDestroy()
    }
}

/** Starts the watcher again after the phone restarts, if it was on. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Store.init(context)
        if (Store.watching && Store.watch.isNotEmpty()) WatchService.start(context)
    }
}
