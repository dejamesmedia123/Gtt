package online.pipsprop.alerts

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sign
import kotlin.math.sqrt

/*
 * Market structure (STX): support and resistance lines found from swing points, channels, and one consolidation area.
 * A Kotlin port of the STX engine in the PipsProp chart (otc-chart.js). It gives no buy or sell signal; it shows where price
 * has reacted before.
 */

class StxParams(
    val fast: Int = 5,
    val slow: Int = 15,
    val tol: Double = 0.5,
    val touches: Int = 3,
    val minSpan: Int = 20,
    val recent: Int = 120,
    val brk: Double = 0.6,
    val viol: Int = 2,
    val par: Double = 0.6,
    val grace: Int = 30,
    val cross: Double = 8.0,
    val wmin: Double = 2.5,
    val wmax: Double = 14.0,
    val maxLines: Int = 2,
)

class Pt(val i: Int, val p: Double)

/** A line y(i) = c + s * i. side 'S' = support (price stays above), 'R' = resistance (price stays below). */
class StxLine(val side: Char, val s: Double, val c: Double, val first: Int, val last: Int, val touches: Int, val brk: Int) {
    fun y(i: Int): Double = c + s * i
}

data class StxArea(val i0: Int, val w: Int, val a: Double, val b: Double, val up: Double, val dn: Double, val wA: Double, val tS: Long, val c0: Double)

class StxState {
    var area: StxArea? = null
    var retired: StxArea? = null
    var tf = 0L
    var lastZone = 0               // -1 below the area, 0 inside, 1 above
    var lastAreaT = 0L
    var liveKeys: Set<String> = emptySet()
    fun reset() {
        area = null; retired = null; tf = 0L; lastZone = 0; lastAreaT = 0L; liveKeys = emptySet()
    }
}

class StxResult(
    val n: Int,
    val times: LongArray,
    val lines: List<StxLine>,
    val support: StxLine?,
    val resistance: StxLine?,
    val channelKind: String?,
    val area: StxArea?,
    val retired: StxArea?,
    val atr: Double,
    val px: Double,
) {
    fun key(l: StxLine): String = l.side.toString() + ":" + times[l.first]
}

object Stx {
    private val WINDOWS = intArrayOf(240, 160, 80)

    private fun med(a: List<Double>): Double {
        if (a.isEmpty()) return 0.0
        val s = a.sorted()
        val m = s.size shr 1
        return if (s.size % 2 == 1) s[m] else (s[m - 1] + s[m]) / 2.0
    }

    private fun pct(a: DoubleArray, q: Double): Double {
        val s = a.sorted()
        val idx = Math.round(q * (s.size - 1)).toInt()
        return s[minOf(s.size - 1, maxOf(0, idx))]
    }

    /** Confirmed swing points: a bar that is the highest (lowest) of [span] bars on each side. */
    private fun pivots(hi: DoubleArray, lo: DoubleArray, span: Int, hOut: MutableMap<Int, Double>, lOut: MutableMap<Int, Double>) {
        val n = hi.size
        for (i in span until n - span) {
            var h = true
            var l = true
            var j = i - span
            while (j <= i + span && (h || l)) {
                if (hi[j] > hi[i]) h = false
                if (lo[j] < lo[i]) l = false
                j += 1
            }
            if (h) hOut[i] = hi[i]
            if (l) lOut[i] = lo[i]
        }
    }

    private fun toList(m: Map<Int, Double>): List<Pt> = m.entries.sortedBy { it.key }.map { Pt(it.key, it.value) }.takeLast(48)

    private fun findLines(piv: List<Pt>, side: Char, o: StxParams, hi: DoubleArray, lo: DoubleArray, cl: DoubleArray, atr: DoubleArray): List<StxLine> {
        val n = cl.size
        val aL = atr[n - 1]
        val found = ArrayList<StxLine>()
        val seen = HashSet<String>()
        val isS = side == 'S'
        for (x in piv.indices) {
            for (y in x + 1 until piv.size) {
                val a = piv[x]
                val b = piv[y]
                if (b.i - a.i < 5) continue
                val s = (b.p - a.p) / (b.i - a.i)
                val t = piv.filter { q -> abs(q.p - (a.p + s * (q.i - a.i))) <= o.tol * atr[q.i] }
                if (t.size < o.touches) continue
                val key = t.first().i.toString() + "," + t.last().i + "," + t.size
                if (!seen.add(key)) continue
                // robust fit: median of pairwise slopes, then shifted onto the outermost touch so it acts as a boundary
                val sl = ArrayList<Double>()
                for (u in t.indices) for (v in u + 1 until t.size) if (t[v].i > t[u].i) sl.add((t[v].p - t[u].p) / (t[v].i - t[u].i))
                val s2 = med(sl)
                var c = if (isS) Double.POSITIVE_INFINITY else Double.NEGATIVE_INFINITY
                for (q in t) {
                    val k = q.p - s2 * q.i
                    c = if (isS) minOf(c, k) else maxOf(c, k)
                }
                val first = t.first().i
                val last = t.last().i
                if (last - first < o.minSpan || last < n - 1 - o.recent) continue
                var viol = 0
                var brk = -1
                var bad = false
                for (i in first until n) {
                    val v = c + s2 * i
                    val pen = if (isS) v - lo[i] else hi[i] - v
                    val cp = if (isS) v - cl[i] else cl[i] - v
                    if (pen > o.brk * atr[i] || cp > 0.3 * atr[i]) {
                        if (i <= last) bad = true else brk = i
                        break
                    }
                    if (cp > 0.05 * atr[i]) {
                        viol += 1
                        if (viol > o.viol) {
                            bad = true
                            break
                        }
                    }
                }
                if (bad) continue
                if (brk >= 0 && n - 1 - brk > o.grace) continue
                found.add(StxLine(side, s2, c, first, last, t.size, brk))
            }
        }
        found.sortWith(compareByDescending<StxLine> { it.touches }.thenByDescending { it.last - it.first }.thenByDescending { it.last })
        val keep = ArrayList<StxLine>()
        for (f in found) {
            if (keep.any { k -> abs(k.y(n - 1) - f.y(n - 1)) < 0.5 * aL && abs(k.s - f.s) * 50 < 0.3 * aL }) continue
            keep.add(f)
            if (keep.size >= o.maxLines) break
        }
        return keep
    }

    /** One consolidation area: a sloped baseline with upper and lower rails, windows from longest to shortest. */
    private fun findArea(n: Int, hi: DoubleArray, lo: DoubleArray, cl: DoubleArray, atr: DoubleArray, o: StxParams): StxArea? {
        val aL = atr[n - 1]
        for (w in WINDOWS) {
            if (n < w + 5) continue
            val i0 = n - w
            var sx = 0.0
            var sy = 0.0
            var sxx = 0.0
            var sxy = 0.0
            for (k in 0 until w) {
                sx += k
                sy += cl[i0 + k]
                sxx += k.toDouble() * k
                sxy += k * cl[i0 + k]
            }
            val den = w * sxx - sx * sx
            val b = (w * sxy - sx * sy) / den
            val a = (sy - b * sx) / w
            val rh = DoubleArray(w)
            val rl = DoubleArray(w)
            val rc = DoubleArray(w)
            var ssr = 0.0
            var sst = 0.0
            val mc = sy / w
            for (k in 0 until w) {
                val base = a + b * k
                rh[k] = hi[i0 + k] - base
                rl[k] = lo[i0 + k] - base
                rc[k] = cl[i0 + k] - base
                ssr += (cl[i0 + k] - base) * (cl[i0 + k] - base)
                sst += (cl[i0 + k] - mc) * (cl[i0 + k] - mc)
            }
            val up = pct(rh, 0.92)
            val dn = pct(rl, 0.08)
            val width = up - dn
            val wA = width / aL
            if (!(wA >= o.wmin && wA <= o.wmax)) continue
            if (abs(b) * w / aL > 3) continue                                  // only a moderate slope
            if (sst > 0 && 1 - ssr / sst > 0.75) continue                      // a clean one-way drift is a trend, not a range
            val mr = rc.average()
            var sdv = 0.0
            for (v in rc) sdv += (v - mr) * (v - mr)
            val sd = sqrt(sdv / w)
            if (sd / width < 0.15) continue                                    // price must spread through the area
            val mid = (up + dn) / 2
            var cr = 0
            var prev = 0
            var inside = 0
            var tU = -9
            var tL = -9
            var nU = 0
            var nL = 0
            for (k in 0 until w) {
                val sg = sign(rc[k] - mid).toInt()
                if (sg != 0 && prev != 0 && sg != prev) cr += 1
                if (sg != 0) prev = sg
                if (rc[k] <= up && rc[k] >= dn) inside += 1
                if (rh[k] >= up - 0.25 * aL && k - tU >= 5) { nU += 1; tU = k }
                if (rl[k] <= dn + 0.25 * aL && k - tL >= 5) { nL += 1; tL = k }
            }
            if (cr * 100.0 / w < o.cross) continue
            if (nU < 2 || nL < 2) continue
            if (inside.toDouble() / w < 0.8) continue
            return StxArea(i0, w, a, b, up, dn, wA, 0L, 0.0)
        }
        return null
    }

    private fun bsearch(t: LongArray, x: Long): Int {
        var lo = 0
        var hi = t.size - 1
        while (lo <= hi) {
            val m = (lo + hi) ushr 1
            if (t[m] == x) return m
            if (t[m] < x) lo = m + 1 else hi = m - 1
        }
        return -1
    }

    /** [cs] must hold closed candles only. Returns null when there are too few candles. */
    fun analyze(cs: List<Candle>, st: StxState, p: StxParams = StxParams()): StxResult? {
        val n = cs.size
        if (n < 90) return null
        val hi = DoubleArray(n) { cs[it].h }
        val lo = DoubleArray(n) { cs[it].l }
        val cl = DoubleArray(n) { cs[it].c }
        val t = LongArray(n) { cs[it].t }
        val raw = Ind.atr(cs, 14)
        val atr = DoubleArray(n)
        var fill = Double.NaN
        for (i in 0 until n) {
            val v = raw[i]
            if (!v.isNaN() && v > 0) { atr[i] = v; fill = v } else atr[i] = fill
        }
        val f0 = atr.firstOrNull { !it.isNaN() } ?: return null
        for (i in 0 until n) if (atr[i].isNaN()) atr[i] = f0
        val aL = atr[n - 1]
        val px = cl[n - 1]
        val tf = if (n > 1) t[n - 1] - t[n - 2] else 0L

        val hMap = HashMap<Int, Double>()
        val lMap = HashMap<Int, Double>()
        pivots(hi, lo, p.fast, hMap, lMap)
        pivots(hi, lo, p.slow, hMap, lMap)
        val ph = toList(hMap)
        val pl = toList(lMap)
        val sup = findLines(pl, 'S', p, hi, lo, cl, atr)
        val res = findLines(ph, 'R', p, hi, lo, cl, atr)
        val s0 = sup.firstOrNull { it.brk < 0 }
        val r0 = res.firstOrNull { it.brk < 0 }

        // channel: the strongest live support and resistance with similar slopes, resistance above support
        var kind: String? = null
        if (s0 != null && r0 != null && abs(s0.s - r0.s) * 50 <= p.par * aL) {
            val stI = max(s0.first, r0.first)
            if (r0.y(n - 1) > s0.y(n - 1) && r0.y(stI) > s0.y(stI)) {
                val avg = (s0.s + r0.s) / 2
                kind = if (abs(avg) * 50 < 0.25 * aL) "range" else if (avg > 0) "up" else "down"
            }
        }

        // consolidation area: its shape is fixed when it is confirmed, then it only ages
        if (st.tf != tf) {
            st.area = null
            st.retired = null
            st.tf = tf
        }
        var area = st.area
        if (area != null) {
            val i0 = bsearch(t, area.tS)
            if (i0 < 0 || abs(cl[i0] - area.c0) > 1e-9 * max(1.0, abs(area.c0))) {
                st.area = null
                area = null
                st.retired = null
            } else {
                val cur = area.copy(i0 = i0)
                val e = i0 + cur.w - 1
                val age = n - 1 - e
                var inside = 0
                var cnt = 0
                for (i in e + 1 until n) {
                    val k = i - i0
                    val bs = cur.a + cur.b * k
                    cnt += 1
                    if (cl[i] <= bs + cur.up && cl[i] >= bs + cur.dn) inside += 1
                }
                if (age >= 400 || (cnt >= 10 && inside.toDouble() / cnt < 0.6)) {
                    st.retired = cur
                    st.area = null
                    area = null
                } else {
                    st.area = cur
                    area = cur
                }
            }
        }
        if (area == null) {
            val f = findArea(n, hi, lo, cl, atr, p)
            if (f != null) {
                val fa = f.copy(tS = t[f.i0], c0 = cl[f.i0])
                st.area = fa
                area = fa
            }
        }
        if (area != null) {
            val i = bsearch(t, area.tS)
            if (i < 0) {
                st.area = null
                area = null
            } else {
                area = area.copy(i0 = i)
            }
        }
        var retired = st.retired
        if (retired != null) {
            val i = bsearch(t, retired.tS)
            if (i < 0) {
                st.retired = null
                retired = null
            } else {
                retired = retired.copy(i0 = i)
            }
        }
        return StxResult(n, t, sup + res, s0, r0, kind, area, retired, aL, px)
    }
}
