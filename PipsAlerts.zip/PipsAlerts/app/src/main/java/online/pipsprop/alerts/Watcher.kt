package online.pipsprop.alerts

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlin.math.abs
import kotlin.math.min

/** What the watcher remembers about one market + timeframe between candles. */
class SeriesState {
    val startedAt = System.currentTimeMillis()
    var baselineDone = false            // the first analysis only records what is already true, it does not alert
    var lastClosedT = 0L
    var lastNearAt = 0L
    var ribbon: RibbonResult? = null
    var iso: IsoResult? = null
    var stx: StxResult? = null
    val stxState = StxState()
    val isoState = IsoState()
}

/** Runs one feed per watched market, analyses each new closed candle with the three strategies, and sends the alerts. */
object Watcher {
    private var scope: CoroutineScope? = null
    private val feeds = HashMap<String, SeriesFeed>()
    private var ctx: Context? = null
    @Volatile var lastUpdate = 0L
    @Volatile var count = 0

    fun start(context: Context, onStatus: (String) -> Unit) {
        stop()
        ctx = context.applicationContext
        val sc = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        scope = sc
        for (w in Store.watch) {
            val m = marketByKey(w.key) ?: continue
            val st = SeriesState()
            val feed = SeriesFeed(m, w.tf, sc, { candles, _, price ->
                try {
                    synchronized(st) { onSeries(w, m, st, candles, price) }
                    lastUpdate = System.currentTimeMillis()
                } catch (e: Exception) {
                    // one bad candle must not stop the watcher
                }
            }, { s -> onStatus(m.name + " " + tfLabel(w.tf) + ": " + s) })
            feeds[w.id] = feed
            feed.start()
        }
        count = feeds.size
        onStatus("Watching " + feeds.size + " markets")
    }

    fun stop() {
        for (f in feeds.values) f.stop()
        feeds.clear()
        scope?.cancel()
        scope = null
        count = 0
    }

    private fun onSeries(w: WatchItem, m: Market, st: SeriesState, candles: List<Candle>, price: Double) {
        val c = ctx ?: return
        val closed = candles.dropLast(1)                  // the last candle is still forming
        if (closed.size < 100) return
        val lastT = closed[closed.size - 1].t
        if (st.lastClosedT != lastT) {
            analyse(c, w, m, st, closed, !st.baselineDone)
            st.lastClosedT = lastT
            st.baselineDone = true
        }
        val now = System.currentTimeMillis()
        if (now - st.lastNearAt >= 2000) {
            st.lastNearAt = now
            nearChecks(c, w, m, st, price, now - st.startedAt < 15_000)
        }
    }

    private fun head(m: Market, w: WatchItem): String = m.name + " " + tfLabel(w.tf)

    // ---- once per closed candle ------------------------------------------------------------

    private fun analyse(c: Context, w: WatchItem, m: Market, st: SeriesState, closed: List<Candle>, silent: Boolean) {
        val dec = m.dec
        val last = closed[closed.size - 1]

        // Trend Target Ribbon
        val rb = Ribbon.analyze(closed)
        st.ribbon = rb
        val pos = rb.pos
        if (pos != null) {
            val base = w.id + ":" + pos.entryT
            val side = if (pos.dir == 1) "LONG" else "SHORT"
            val tps = StringBuilder()
            for (i in pos.targets.indices) tps.append(" T").append(i + 1).append(' ').append(fp(pos.targets[i], dec)).append(if (i < pos.targets.size - 1) "," else "")
            Alerts.fire(c, AlertKind.RIBBON_SIGNAL, head(m, w) + ": " + side + " signal",
                "Entry " + fp(pos.entry, dec) + ". Stop " + fp(pos.stop, dec) + "." + tps, "RS:" + base, silent = silent)
            for (k in 1..pos.hits) {
                Alerts.fire(c, AlertKind.RIBBON_TARGET, head(m, w) + ": target " + k + " reached",
                    side + " from " + fp(pos.entry, dec) + ". T" + k + " at " + fp(pos.targets[k - 1], dec) + " (" + k + "R).", "RT:" + base + ":" + k, silent = silent)
            }
            if (pos.stopped) {
                Alerts.fire(c, AlertKind.RIBBON_STOP, head(m, w) + ": stop level hit",
                    side + " from " + fp(pos.entry, dec) + ". Stop " + fp(pos.stop, dec) + " was touched" + (if (pos.hits > 0) " after T" + pos.hits else "") + ".", "RX:" + base, silent = silent)
            }
        }

        // Isotropic Trend Lines
        val iso = Iso.analyze(closed, Store.isoPeriod, 5, 0.5, 20)
        st.iso = iso
        for (e in Iso.step(st.isoState, iso, last, dec)) {
            Alerts.fire(c, e.kind, head(m, w) + ": " + e.kind.label.lowercase(), e.text, "ISO:" + w.id + ":" + last.t + ":" + e.key, silent = silent)
        }

        // Market structure
        val sx = Stx.analyze(closed, st.stxState)
        st.stx = sx
        if (sx != null) {
            val live = HashSet<String>()
            for (l in sx.lines) if (l.brk < 0) live.add(sx.key(l))
            for (l in sx.lines) {
                if (l.brk >= 0 && sx.key(l) in st.stxState.liveKeys) {
                    val what = if (l.side == 'S') "support" else "resistance"
                    Alerts.fire(c, AlertKind.STX_BROKEN, head(m, w) + ": " + what + " broken",
                        "The " + what + " line with " + l.touches + " touches near " + fp(l.y(sx.n - 1), dec) + " was broken. Price " + fp(last.c, dec) + ".", "SB:" + w.id + ":" + sx.key(l) + ":" + l.brk, silent = silent)
                }
            }
            st.stxState.liveKeys = live
            val a = sx.area
            if (a != null) {
                val k = sx.n - 1 - a.i0
                val bs = a.a + a.b * k
                val zone = if (last.c > bs + a.up) 1 else if (last.c < bs + a.dn) -1 else 0
                if (st.stxState.lastAreaT == a.tS && st.stxState.lastZone == 0 && zone != 0) {
                    Alerts.fire(c, AlertKind.STX_AREA_EXIT, head(m, w) + ": price left the range",
                        "Price " + fp(last.c, dec) + " moved " + (if (zone > 0) "above" else "below") + " the consolidation area (" + fp(bs + a.dn, dec) + " to " + fp(bs + a.up, dec) + ").", "SA:" + w.id + ":" + last.t, silent = silent)
                }
                st.stxState.lastAreaT = a.tS
                st.stxState.lastZone = zone
            } else {
                st.stxState.lastAreaT = 0L
                st.stxState.lastZone = 0
            }
        }
    }

    // ---- on every price update (checked every 2 seconds) -------------------------------------

    private fun nearChecks(c: Context, w: WatchItem, m: Market, st: SeriesState, price: Double, silent: Boolean) {
        val dec = m.dec
        val cd = Store.cooldownMin * 60_000L
        val lastT = st.lastClosedT

        val rb = st.ribbon
        if (rb != null) {
            val pos = rb.pos
            if (pos != null && pos.active && pos.hits < pos.targets.size && pos.risk > 0) {
                val tp = pos.targets[pos.hits]
                val approaching = if (pos.dir == 1) price < tp else price > tp
                val distR = abs(price - tp) / pos.risk
                if (approaching && distR <= Store.nearTargetR) {
                    val k = pos.hits + 1
                    Alerts.fire(c, AlertKind.RIBBON_NEAR_TARGET, head(m, w) + ": near target " + k,
                        "Price " + fp(price, dec) + " is " + fp(distR, 2) + "R away from T" + k + " (" + fp(tp, dec) + ").", "RNT:" + w.id + ":" + pos.entryT + ":" + k, silent = silent)
                }
            }
            val n = rb.alma.size
            if (n > 0 && rb.trend[n - 1] != 0) {
                val alma = rb.alma[n - 1]
                val atr = rb.atr[n - 1]
                if (!alma.isNaN() && !atr.isNaN() && atr > 0) {
                    val d = abs(price - alma) / atr
                    if (d <= Store.nearLineAtr) {
                        val dir = if (rb.trend[n - 1] == 1) "UP" else "DOWN"
                        Alerts.fire(c, AlertKind.RIBBON_NEAR_LINE, head(m, w) + ": near the trend line",
                            "Trend " + dir + ". Price " + fp(price, dec) + " is " + fp(d, 2) + " ATR from the trend line (" + fp(alma, dec) + ").", "RNL:" + w.id + ":" + lastT,
                            cooldownKey = "RNL:" + w.id, cooldownMs = cd, silent = silent)
                    }
                }
            }
        }

        val iso = st.iso
        val p = iso?.primary
        if (iso != null && p != null && !iso.atr.isNaN() && iso.atr > 0) {
            val dU = abs(price - p.upper) / iso.atr
            val dL = abs(price - p.lower) / iso.atr
            val inside = price <= p.upper + iso.atr * Store.nearEdgeAtr && price >= p.lower - iso.atr * Store.nearEdgeAtr
            if (inside && min(dU, dL) <= Store.nearEdgeAtr) {
                val ceiling = dU <= dL
                Alerts.fire(c, AlertKind.ISO_NEAR_EDGE, head(m, w) + ": near the channel " + (if (ceiling) "ceiling" else "floor"),
                    "Price " + fp(price, dec) + " is " + fp(min(dU, dL), 2) + " ATR from the " + (if (ceiling) "ceiling " + fp(p.upper, dec) else "floor " + fp(p.lower, dec)) + ".",
                    "INE:" + w.id + ":" + lastT + ":" + (if (ceiling) "u" else "l"), cooldownKey = "INE:" + w.id, cooldownMs = cd, silent = silent)
            }
        }

        val sx = st.stx
        if (sx != null && sx.atr > 0) {
            val tol = Store.nearStructAtr * sx.atr
            val s0 = sx.support
            val r0 = sx.resistance
            if (s0 != null && abs(price - s0.y(sx.n - 1)) <= tol) {
                Alerts.fire(c, AlertKind.STX_NEAR, head(m, w) + ": near support",
                    "Price " + fp(price, dec) + " is at a support line (" + s0.touches + " touches) near " + fp(s0.y(sx.n - 1), dec) + ".", "SN:" + w.id + ":S:" + lastT,
                    cooldownKey = "SN:" + w.id + ":S", cooldownMs = cd, silent = silent)
            }
            if (r0 != null && abs(price - r0.y(sx.n - 1)) <= tol) {
                Alerts.fire(c, AlertKind.STX_NEAR, head(m, w) + ": near resistance",
                    "Price " + fp(price, dec) + " is at a resistance line (" + r0.touches + " touches) near " + fp(r0.y(sx.n - 1), dec) + ".", "SN:" + w.id + ":R:" + lastT,
                    cooldownKey = "SN:" + w.id + ":R", cooldownMs = cd, silent = silent)
            }
        }
    }
}
