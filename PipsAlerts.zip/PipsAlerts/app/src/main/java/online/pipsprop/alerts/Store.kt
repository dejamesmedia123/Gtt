package online.pipsprop.alerts

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class AlertRecord(val time: Long, val title: String, val text: String, val kind: String, val mode: Int, val silent: Boolean)

/** Everything the app remembers: the watch list, alert settings, thresholds, and the alert history. */
object Store {
    private var sp: SharedPreferences? = null

    var watch by mutableStateOf<List<WatchItem>>(emptyList())
    var modes by mutableStateOf<Map<String, Int>>(emptyMap())
    var history by mutableStateOf<List<AlertRecord>>(emptyList())

    var nearTargetR by mutableStateOf(0.65)      // "near a target": within this many risk units (R) of it
    var nearLineAtr by mutableStateOf(0.5)       // "near the trend line": within this many ATR of it
    var nearEdgeAtr by mutableStateOf(0.5)       // "near the channel edge"
    var nearStructAtr by mutableStateOf(0.5)     // "near support / resistance"
    var cooldownMin by mutableStateOf(30)        // the same kind of "near" alert for a market at most once per this many minutes
    var quietOn by mutableStateOf(false)
    var quietFrom by mutableStateOf(22)
    var quietTo by mutableStateOf(7)
    var isoPeriod by mutableStateOf(19)
    var watching by mutableStateOf(false)        // the watcher was on, so it restarts after a reboot
    var chartKey by mutableStateOf("BINANCE:BTCUSDT")
    var chartTf by mutableStateOf(900)

    private val seen = LinkedHashSet<String>()

    fun init(ctx: Context) {
        if (sp != null) return
        val s = ctx.applicationContext.getSharedPreferences("pp_alerts", Context.MODE_PRIVATE)
        sp = s
        fun d(k: String, def: Double): Double = s.getString(k, null)?.toDoubleOrNull() ?: def
        nearTargetR = d("ntr", 0.65)
        nearLineAtr = d("nla", 0.5)
        nearEdgeAtr = d("nea", 0.5)
        nearStructAtr = d("nsa", 0.5)
        cooldownMin = s.getInt("cool", 30)
        quietOn = s.getBoolean("qon", false)
        quietFrom = s.getInt("qf", 22)
        quietTo = s.getInt("qt", 7)
        isoPeriod = s.getInt("isop", 19)
        watching = s.getBoolean("watching", false)
        chartKey = s.getString("ckey", "BINANCE:BTCUSDT") ?: "BINANCE:BTCUSDT"
        chartTf = s.getInt("ctf", 900)
        try {
            val a = JSONArray(s.getString("watch", "[]"))
            watch = (0 until a.length()).map { a.getJSONObject(it) }.map { WatchItem(it.getString("k"), it.getInt("tf")) }
        } catch (e: Exception) {
            watch = emptyList()
        }
        try {
            val o = JSONObject(s.getString("modes", "{}"))
            val m = HashMap<String, Int>()
            for (k in o.keys()) m[k] = o.getInt(k)
            modes = m
        } catch (e: Exception) {
            modes = emptyMap()
        }
        try {
            val a = JSONArray(s.getString("history", "[]"))
            history = (0 until a.length()).map { a.getJSONObject(it) }.map {
                AlertRecord(it.getLong("t"), it.optString("title"), it.optString("text"), it.optString("kind"), it.optInt("mode"), it.optBoolean("silent"))
            }
        } catch (e: Exception) {
            history = emptyList()
        }
        try {
            val a = JSONArray(s.getString("seen", "[]"))
            synchronized(seen) { for (i in 0 until a.length()) seen.add(a.getString(i)) }
        } catch (e: Exception) {
            // start empty
        }
    }

    fun save() {
        val s = sp ?: return
        val w = JSONArray()
        for (x in watch) w.put(JSONObject().put("k", x.key).put("tf", x.tf))
        val m = JSONObject()
        for ((k, v) in modes) m.put(k, v)
        s.edit()
            .putString("ntr", nearTargetR.toString())
            .putString("nla", nearLineAtr.toString())
            .putString("nea", nearEdgeAtr.toString())
            .putString("nsa", nearStructAtr.toString())
            .putInt("cool", cooldownMin)
            .putBoolean("qon", quietOn)
            .putInt("qf", quietFrom)
            .putInt("qt", quietTo)
            .putInt("isop", isoPeriod)
            .putBoolean("watching", watching)
            .putString("ckey", chartKey)
            .putInt("ctf", chartTf)
            .putString("watch", w.toString())
            .putString("modes", m.toString())
            .apply()
    }

    fun modeOf(k: AlertKind): Int = modes[k.name] ?: k.defaultMode

    fun setMode(k: AlertKind, mode: Int) {
        val m = HashMap(modes)
        m[k.name] = mode
        modes = m
        save()
    }

    /** True the first time an id is seen, false after. Persisted, so a restart does not repeat old alerts. */
    fun markSeen(id: String): Boolean {
        synchronized(seen) {
            if (!seen.add(id)) return false
            while (seen.size > 600) {
                val it = seen.iterator()
                it.next()
                it.remove()
            }
            val a = JSONArray()
            for (x in seen) a.put(x)
            sp?.edit()?.putString("seen", a.toString())?.apply()
        }
        return true
    }

    fun addHistory(r: AlertRecord) {
        synchronized(this) {
            history = (listOf(r) + history).take(100)
            val a = JSONArray()
            for (x in history) a.put(JSONObject().put("t", x.time).put("title", x.title).put("text", x.text).put("kind", x.kind).put("mode", x.mode).put("silent", x.silent))
            sp?.edit()?.putString("history", a.toString())?.apply()
        }
    }

    fun clearHistory() {
        synchronized(this) {
            history = emptyList()
            sp?.edit()?.putString("history", "[]")?.apply()
        }
    }
}
