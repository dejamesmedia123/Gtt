package online.pipsprop.alerts

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

/** Notification channels, the rules for when an alert may fire, and posting it. */
object Alerts {
    const val CH_WATCH = "watch"
    const val CH_ALERT = "alerts_v1"
    const val CH_URGENT = "urgent_v1"

    private val lastFired = HashMap<String, Long>()
    private var counter = 100

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val watch = NotificationChannel(CH_WATCH, "Watcher running", NotificationManager.IMPORTANCE_LOW)
        watch.description = "The permanent notification that shows the app is watching your markets."
        nm.createNotificationChannel(watch)

        val alert = NotificationChannel(CH_ALERT, "Price alerts", NotificationManager.IMPORTANCE_HIGH)
        alert.description = "Normal alerts: signals, targets, price near a level."
        alert.enableVibration(true)
        alert.vibrationPattern = longArrayOf(0, 250, 150, 250)
        nm.createNotificationChannel(alert)

        val urgent = NotificationChannel(CH_URGENT, "Urgent alerts", NotificationManager.IMPORTANCE_HIGH)
        urgent.description = "Loud alerts: alarm sound, full screen on the lock screen, and they can override Do Not Disturb."
        urgent.enableVibration(true)
        urgent.vibrationPattern = longArrayOf(0, 600, 200, 600, 200, 600)
        urgent.setBypassDnd(true)
        urgent.lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
        urgent.setSound(
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
        )
        nm.createNotificationChannel(urgent)
    }

    fun inQuietHours(): Boolean {
        if (!Store.quietOn || Store.quietFrom == Store.quietTo) return false
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (Store.quietFrom < Store.quietTo) h >= Store.quietFrom && h < Store.quietTo else h >= Store.quietFrom || h < Store.quietTo
    }

    /**
     * Sends one alert if its type is on. [id] makes sure it is sent only once (it is remembered, also across restarts).
     * [silent] only remembers the id without notifying (used for what was already true when the app started).
     */
    fun fire(
        ctx: Context,
        kind: AlertKind,
        title: String,
        text: String,
        id: String,
        cooldownKey: String? = null,
        cooldownMs: Long = 0L,
        silent: Boolean = false,
    ): Boolean {
        val mode = Store.modeOf(kind)
        if (mode == 0) return false
        val now = System.currentTimeMillis()
        if (!silent && cooldownKey != null && cooldownMs > 0) {
            val last = synchronized(lastFired) { lastFired[cooldownKey] ?: 0L }
            if (now - last < cooldownMs) return false
        }
        if (!Store.markSeen(id)) return false
        if (silent) return false
        if (cooldownKey != null) synchronized(lastFired) { lastFired[cooldownKey] = now }
        // quiet hours hold back everything except urgent alerts; they are still listed in the history
        val quiet = inQuietHours() && mode < 2
        Store.addHistory(AlertRecord(now, title, text, kind.name, mode, quiet))
        if (!quiet) post(ctx, title, text, mode == 2)
        return true
    }

    fun test(ctx: Context, urgent: Boolean) {
        Store.addHistory(AlertRecord(System.currentTimeMillis(), "Test alert", if (urgent) "This is an urgent test alert." else "This is a normal test alert.", "TEST", if (urgent) 2 else 1, false))
        post(ctx, "Test alert", if (urgent) "This is an urgent test alert. It should ring and show on the lock screen." else "This is a normal test alert.", urgent)
    }

    private fun post(ctx: Context, title: String, text: String, urgent: Boolean) {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        ensureChannels(ctx)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), flags)
        val b = NotificationCompat.Builder(ctx, if (urgent) CH_URGENT else CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(if (urgent) NotificationCompat.CATEGORY_ALARM else NotificationCompat.CATEGORY_MESSAGE)
            .setWhen(System.currentTimeMillis())
        if (urgent) {
            val full = Intent(ctx, AlertActivity::class.java)
                .putExtra("title", title).putExtra("text", text)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            b.setFullScreenIntent(PendingIntent.getActivity(ctx, 1, full, flags), true)
            b.setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        }
        val nid = synchronized(this) { counter += 1; counter }
        nm.notify(nid, b.build())
    }
}
