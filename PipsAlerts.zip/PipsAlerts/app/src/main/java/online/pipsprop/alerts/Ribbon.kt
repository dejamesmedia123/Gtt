/*
 * Trend Target Ribbon: a Kotlin port of the Pine Script indicator "Trend Target Ribbon [BOSWaves]" (c) BOSWaves.
 * The original is licensed under the Mozilla Public License 2.0, and so is this file.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
 * If a copy of the MPL was not distributed with this file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * Only the trend, entry, stop and target logic is ported. The drawing is done by this app's own chart.
 */
package online.pipsprop.alerts

import kotlin.math.max
import kotlin.math.min

class RibbonParams(
    val almaLen: Int = 34,
    val almaOffset: Double = 0.85,
    val almaSigma: Double = 6.0,
    val devLen: Int = 34,
    val devMult: Double = 0.65,
    val slopeLen: Int = 3,
    val slopeMin: Double = 0.08,
    val atrLen: Int = 14,
    val stopLookback: Int = 12,
    val minStopAtr: Double = 0.75,
    val maxStopAtr: Double = 3.0,
    val targetCount: Int = 4,
)

/** One trade plan: entry at the close of the signal candle, a structure stop, and targets at 1R, 2R, 3R, 4R. */
class RibbonPos(
    val dir: Int,
    val entryIdx: Int,
    val entryT: Long,
    val entry: Double,
    val stop: Double,
    val risk: Double,
    val targets: DoubleArray,
) {
    var hits = 0
    var stopped = false
    var stopIdx = -1
    var endIdx = -1            // the bar where the opposite signal replaced it
    val active: Boolean get() = !stopped && endIdx < 0
}

class RibbonResult(
    val trend: IntArray,
    val alma: DoubleArray,
    val dev: DoubleArray,
    val atr: DoubleArray,
    val pos: RibbonPos?,
)

object Ribbon {
    fun analyze(cs: List<Candle>, p: RibbonParams = RibbonParams()): RibbonResult {
        val n = cs.size
        val close = DoubleArray(n) { cs[it].c }
        val alma = Ind.alma(close, p.almaLen, p.almaOffset, p.almaSigma)
        val dev = Ind.stdev(close, p.devLen)
        val atr = Ind.atr(cs, p.atrLen)
        val trendArr = IntArray(n)
        var trend = 0
        var pos: RibbonPos? = null

        for (i in 0 until n) {
            val a = alma[i]
            val d = dev[i]
            val at = atr[i]
            if (i < p.slopeLen || a.isNaN() || d.isNaN() || at.isNaN() || alma[i - p.slopeLen].isNaN()) {
                trendArr[i] = trend
                continue
            }
            val slope = if (at > 0) (a - alma[i - p.slopeLen]) / at else 0.0
            val bullSetup = slope > p.slopeMin && cs[i].c > a + d * p.devMult
            val bearSetup = slope < -p.slopeMin && cs[i].c < a - d * p.devMult
            var flip = false
            if (trend != 1 && bullSetup) {
                trend = 1
                flip = true
            } else if (trend != -1 && bearSetup) {
                trend = -1
                flip = true
            }
            trendArr[i] = trend

            if (flip) {
                // the old plan ends, a new one starts at this candle's close
                val old = pos
                if (old != null && old.active) old.endIdx = i
                val dir = if (trend == 1) 1 else -1
                var rawRisk = Double.NaN
                if (i - p.stopLookback >= 0) {
                    if (dir == 1) {
                        var lo = Double.MAX_VALUE
                        for (k in i - p.stopLookback until i) lo = min(lo, cs[k].l)
                        rawRisk = cs[i].c - lo
                    } else {
                        var hi = -Double.MAX_VALUE
                        for (k in i - p.stopLookback until i) hi = max(hi, cs[k].h)
                        rawRisk = hi - cs[i].c
                    }
                }
                val minR = at * p.minStopAtr
                val maxR = at * p.maxStopAtr
                val risk = min(max(if (rawRisk.isNaN()) minR else rawRisk, minR), maxR)
                val entry = cs[i].c
                val targets = DoubleArray(p.targetCount) { entry + dir * risk * (it + 1) }
                pos = RibbonPos(dir, i, cs[i].t, entry, entry - dir * risk, risk, targets)
            } else {
                val ps = pos
                if (ps != null && ps.active && i > ps.entryIdx) {
                    // if one candle touches both the stop and a target, the stop is assumed first (the cautious reading)
                    val stopTouched = if (ps.dir == 1) cs[i].l <= ps.stop else cs[i].h >= ps.stop
                    if (stopTouched) {
                        ps.stopped = true
                        ps.stopIdx = i
                    } else {
                        while (ps.hits < ps.targets.size) {
                            val tp = ps.targets[ps.hits]
                            val hit = if (ps.dir == 1) cs[i].h >= tp else cs[i].l <= tp
                            if (hit) ps.hits += 1 else break
                        }
                    }
                }
            }
        }
        return RibbonResult(trendArr, alma, dev, atr, pos)
    }
}
