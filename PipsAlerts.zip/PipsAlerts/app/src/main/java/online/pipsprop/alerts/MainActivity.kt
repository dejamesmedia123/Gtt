package online.pipsprop.alerts

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        Alerts.ensureChannels(this)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Brand.Blue, onPrimary = Color.White,
                    background = Color.White, surface = Color.White,
                    surfaceVariant = Brand.Surface, secondaryContainer = Color(0xFFE8E8FF),
                ),
            ) {
                Root()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // if the watcher should be on (for example after the app was closed), make sure the screen shows the real state
        if (Store.watching && Store.watch.isNotEmpty() && !WatchService.running) WatchService.start(this)
    }
}

@Composable
private fun Root() {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    val names = listOf("Alerts", "Watch", "Chart", "Settings")
    val marks = listOf("\uD83D\uDD14", "\uD83D\uDC41", "\uD83D\uDCC8", "\u2699")
    Scaffold(
        containerColor = Color.White,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                names.forEachIndexed { i, n ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(marks[i]) }, label = { Text(n) })
                }
            }
        },
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (tab) {
                0 -> AlertsScreen()
                1 -> WatchScreen()
                2 -> ChartScreen()
                else -> SettingsScreen()
            }
        }
    }
}
