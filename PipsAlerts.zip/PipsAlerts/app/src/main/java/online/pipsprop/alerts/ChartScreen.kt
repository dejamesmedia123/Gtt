package online.pipsprop.alerts

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/** Loads one market, keeps it live, and runs the three strategies on every new closed candle. */
class ChartModel(private val scope: CoroutineScope) {
    var candles by mutableStateOf<List<Candle>>(emptyList())
    var ribbon by mutableStateOf<RibbonResult?>(null)
    var iso by mutableStateOf<IsoResult?>(null)
    var stx by mutableStateOf<StxResult?>(null)
    var status by mutableStateOf("loading...")
    private var feed: SeriesFeed? = null
    private var lastClosed = 0L
    private val stxState = StxState()
    private val main = Handler(Looper.getMainLooper())

    fun open(m: Market, tf: Int) {
        feed?.stop()
        candles = emptyList()
        ribbon = null
        iso = null
        stx = null
        lastClosed = 0L
        stxState.reset()
        status = "loading..."
        val f = SeriesFeed(m, tf, scope, { list, _, _ -> onData(list) }, { s -> main.post { status = s } })
        feed = f
        f.start()
    }

    private fun onData(list: List<Candle>) {
        val closed = list.dropLast(1)
        var rb: RibbonResult? = null
        var io: IsoResult? = null
        var sx: StxResult? = null
        var fresh = false
        if (closed.size >= 100 && closed[closed.size - 1].t != lastClosed) {
            lastClosed = closed[closed.size - 1].t
            try {
                rb = Ribbon.analyze(closed)
                io = Iso.analyze(closed, Store.isoPeriod, 5, 0.5, 20)
                sx = Stx.analyze(closed, stxState)
                fresh = true
            } catch (e: Exception) {
                // show candles even if an analysis fails
            }
        }
        main.post {
            candles = list
            if (fresh) {
                ribbon = rb
                iso = io
                stx = sx
            }
        }
    }

    fun close() {
        feed?.stop()
        feed = null
    }
}

@Composable
fun ChartScreen() {
    val scope = rememberCoroutineScope()
    val model = remember { ChartModel(scope) }
    var showPicker by remember { mutableStateOf(false) }
    var showRibbon by rememberSaveable { mutableStateOf(true) }
    var showStx by rememberSaveable { mutableStateOf(true) }
    var showIso by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(Store.chartKey, Store.chartTf) {
        marketByKey(Store.chartKey)?.let { model.open(it, Store.chartTf) }
    }
    DisposableEffect(Unit) { onDispose { model.close() } }

    val market = marketByKey(Store.chartKey) ?: MARKETS[0]
    val cs = model.candles
    val last = cs.lastOrNull()

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            SecondaryButton(market.name + "  \u25BE") { showPicker = true }
            Text("", Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.End) {
                Text(if (last != null) fp(last.c, market.dec) else "-", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp,
                    color = if (last != null && last.c >= last.o) Brand.GreenDark else if (last != null) Brand.Red else Brand.Text)
                Muted(model.status)
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((g, label) in TIMEFRAMES) {
                FilterChip(selected = Store.chartTf == g, onClick = { Store.chartTf = g; Store.save() }, label = { Text(label) })
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = showRibbon, onClick = { showRibbon = !showRibbon }, label = { Text("Trend Ribbon") })
            FilterChip(selected = showStx, onClick = { showStx = !showStx }, label = { Text("Structure") })
            FilterChip(selected = showIso, onClick = { showIso = !showIso }, label = { Text("Channel") })
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (cs.size < 2) {
                Text("Loading " + market.name + "...", color = Brand.Muted, modifier = Modifier.align(Alignment.Center))
            } else {
                CandleChart(cs, market.dec, model.ribbon, model.iso, model.stx, showRibbon, showStx, showIso, Modifier.fillMaxSize())
            }
        }
        InfoPanel(model, market.dec, showRibbon, showStx, showIso)
    }

    if (showPicker) {
        MarketPicker(onPick = { Store.chartKey = it.key; Store.save(); showPicker = false }, onDismiss = { showPicker = false })
    }
}

@Composable
private fun InfoPanel(model: ChartModel, dec: Int, showRibbon: Boolean, showStx: Boolean, showIso: Boolean) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        val rb = model.ribbon
        val io = model.iso?.primary
        val sx = model.stx
        if (showRibbon && rb != null) {
            val n = rb.trend.size
            val t = if (n > 0) rb.trend[n - 1] else 0
            val pos = rb.pos
            var line = "Ribbon: trend " + (if (t == 1) "UP" else if (t == -1) "DOWN" else "none")
            if (pos != null) {
                line += if (pos.active) ". " + (if (pos.dir == 1) "LONG" else "SHORT") + " from " + fp(pos.entry, dec) + ", stop " + fp(pos.stop, dec) + ", targets hit " + pos.hits + " of " + pos.targets.size
                else ". Last plan " + (if (pos.stopped) "stopped out" else "replaced") + " (" + pos.hits + " targets hit)"
            }
            Text(line, fontSize = 12.sp)
        }
        if (showIso && io != null) {
            Text("Channel: " + (if (io.dir == 1) "UP" else if (io.dir == -1) "DOWN" else "RANGE") + ", angle " + fp(io.angle, 2) + ", " + (model.iso?.agree ?: 0) + " of 6 scales agree. " + fp(io.lower, dec) + " to " + fp(io.upper, dec), fontSize = 12.sp)
        }
        if (showStx && sx != null) {
            val s = sx.support
            val r = sx.resistance
            Text("Structure: " + (if (s != null) "support " + fp(s.y(sx.n - 1), dec) + " (" + s.touches + " touches)" else "no support") + ", " +
                (if (r != null) "resistance " + fp(r.y(sx.n - 1), dec) + " (" + r.touches + " touches)" else "no resistance") +
                (if (sx.area != null) ", range area active" else ""), fontSize = 12.sp)
        }
        Muted("Drag to move, pinch to zoom. Lines are based on closed candles.", 11)
    }
}

private fun ribbonEdge(r: RibbonResult, i: Int): Double {
    val a = r.alma[i]
    val d = r.dev[i]
    if (d.isNaN()) return a
    return when (r.trend[i]) {
        1 -> a - d * 0.55
        -1 -> a + d * 0.55
        else -> a
    }
}

private fun DrawScope.label(text: String, x: Float, y: Float, color: Int, size: Float, alignRight: Boolean = false) {
    drawIntoCanvas { c ->
        val p = android.graphics.Paint()
        p.isAntiAlias = true
        p.color = color
        p.textSize = size
        p.textAlign = if (alignRight) android.graphics.Paint.Align.RIGHT else android.graphics.Paint.Align.LEFT
        c.nativeCanvas.drawText(text, x, y, p)
    }
}

@Composable
private fun CandleChart(
    cs: List<Candle>,
    dec: Int,
    ribbon: RibbonResult?,
    iso: IsoResult?,
    stx: StxResult?,
    showRibbon: Boolean,
    showStx: Boolean,
    showIso: Boolean,
    modifier: Modifier,
) {
    var bars by remember { mutableFloatStateOf(90f) }
    var off by remember { mutableFloatStateOf(0f) }
    val hm = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val dm = remember { SimpleDateFormat("d MMM", Locale.getDefault()) }
    val muted = Brand.Muted.toArgb()
    val dash = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))
    val dots = PathEffect.dashPathEffect(floatArrayOf(4f, 8f))

    Canvas(
        modifier.pointerInput(Unit) {
            detectTransformGestures { _, pan, zoom, _ ->
                val pw0 = size.width - 62.dp.toPx()
                val nb = (bars / zoom).coerceIn(20f, 400f)
                bars = nb
                off = (off + pan.x / (pw0 / nb)).coerceIn(0f, 2000f)
            }
        },
    ) {
        val n = cs.size
        if (n < 2) return@Canvas
        val axisW = 62.dp.toPx()
        val botH = 20.dp.toPx()
        val pw = size.width - axisW
        val ph = size.height - botH
        val barsF = bars.coerceIn(20f, 400f)
        val barW = pw / barsF
        val offI = off.roundToInt().coerceIn(0, n - 1)
        val lastIdx = (n - 1 - offI).coerceIn(0, n - 1)
        val firstIdx = maxOf(0, lastIdx - barsF.toInt() + 1)
        val rightPad = 4

        fun xAt(i: Int): Float = pw - (lastIdx - i + rightPad + 0.5f) * barW

        var lo = Double.MAX_VALUE
        var hi = -Double.MAX_VALUE
        for (i in firstIdx..lastIdx) {
            lo = minOf(lo, cs[i].l)
            hi = maxOf(hi, cs[i].h)
        }
        if (hi <= lo) hi = lo + 1.0
        val padP = (hi - lo) * 0.07
        lo -= padP
        hi += padP
        fun yAt(v: Double): Float = (ph.toDouble() - (v - lo) / (hi - lo) * ph).toFloat()

        // grid and price labels
        for (k in 0..4) {
            val v = lo + (hi - lo) * k / 4.0
            val y = yAt(v)
            drawLine(Brand.Surface2, Offset(0f, y), Offset(pw, y), strokeWidth = 1f)
            label(fp(v, dec), pw + 6f, y + 4f, muted, 11.sp.toPx())
        }
        // time labels
        val step = if (n > 1) cs[1].t - cs[0].t else 60L
        for (k in 0..3) {
            val i = firstIdx + (lastIdx - firstIdx) * k / 3
            val x = xAt(i)
            val text = if (step >= 86400L) dm.format(java.util.Date(cs[i].t * 1000L)) else hm.format(java.util.Date(cs[i].t * 1000L))
            label(text, x, size.height - 4f, muted, 10.sp.toPx(), alignRight = k == 3)
        }

        clipRect(0f, 0f, pw, ph) {
            // ---- market structure: lines and the range area (behind the candles)
            if (showStx && stx != null) {
                val a = stx.area
                if (a != null) {
                    val end = stx.n   // the forming candle
                    val top = Path()
                    val bot = Path()
                    var started = false
                    for (i in maxOf(a.i0, firstIdx - 1)..minOf(end, lastIdx + 1)) {
                        val k = i - a.i0
                        val base = a.a + a.b * k
                        val xT = xAt(i)
                        if (!started) {
                            top.moveTo(xT, yAt(base + a.up)); bot.moveTo(xT, yAt(base + a.dn)); started = true
                        } else {
                            top.lineTo(xT, yAt(base + a.up)); bot.lineTo(xT, yAt(base + a.dn))
                        }
                    }
                    if (started) {
                        val fill = Path()
                        var first = true
                        for (i in maxOf(a.i0, firstIdx - 1)..minOf(end, lastIdx + 1)) {
                            val k = i - a.i0
                            val xT = xAt(i)
                            if (first) { fill.moveTo(xT, yAt(a.a + a.b * k + a.up)); first = false } else fill.lineTo(xT, yAt(a.a + a.b * k + a.up))
                        }
                        for (i in minOf(end, lastIdx + 1) downTo maxOf(a.i0, firstIdx - 1)) {
                            val k = i - a.i0
                            fill.lineTo(xAt(i), yAt(a.a + a.b * k + a.dn))
                        }
                        fill.close()
                        drawPath(fill, Brand.Blue.copy(alpha = 0.07f))
                        drawPath(top, Brand.Blue.copy(alpha = 0.5f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f))
                        drawPath(bot, Brand.Blue.copy(alpha = 0.5f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f))
                    }
                }
                for (l in stx.lines) {
                    val endIdx = if (l.brk >= 0) l.brk else stx.n
                    val col = if (l.side == 'S') Brand.Green else Brand.Red
                    val w = 1.5f + minOf(l.touches, 6) * 0.5f
                    drawLine(
                        if (l.brk >= 0) Brand.Muted.copy(alpha = 0.5f) else col.copy(alpha = 0.85f),
                        Offset(xAt(l.first), yAt(l.y(l.first))), Offset(xAt(endIdx), yAt(l.y(endIdx))),
                        strokeWidth = w, pathEffect = if (l.brk >= 0) dash else null,
                    )
                }
            }

            // ---- channel
            val p = iso?.primary
            if (showIso && p != null) {
                val col = if (p.dir == 1) Brand.Green else if (p.dir == -1) Brand.Red else Brand.Muted
                val a = p.segStart
                val b = p.lastIdx
                val proj = b + 7
                val fill = Path()
                fill.moveTo(xAt(a), yAt(p.upperInt + p.slope * a))
                fill.lineTo(xAt(proj), yAt(p.upperInt + p.slope * proj))
                fill.lineTo(xAt(proj), yAt(p.lowerInt + p.slope * proj))
                fill.lineTo(xAt(a), yAt(p.lowerInt + p.slope * a))
                fill.close()
                drawPath(fill, col.copy(alpha = 0.06f))
                drawLine(col, Offset(xAt(a), yAt(p.upperInt + p.slope * a)), Offset(xAt(b), yAt(p.upperInt + p.slope * b)), strokeWidth = 2.5f)
                drawLine(col, Offset(xAt(a), yAt(p.lowerInt + p.slope * a)), Offset(xAt(b), yAt(p.lowerInt + p.slope * b)), strokeWidth = 2.5f)
                drawLine(col, Offset(xAt(b), yAt(p.upperInt + p.slope * b)), Offset(xAt(proj), yAt(p.upperInt + p.slope * proj)), strokeWidth = 2f, pathEffect = dots)
                drawLine(col, Offset(xAt(b), yAt(p.lowerInt + p.slope * b)), Offset(xAt(proj), yAt(p.lowerInt + p.slope * proj)), strokeWidth = 2f, pathEffect = dots)
            }

            // ---- candles
            for (i in firstIdx..lastIdx) {
                val c = cs[i]
                val x = xAt(i)
                val col = if (c.c >= c.o) Brand.Green else Brand.Red
                drawLine(col, Offset(x, yAt(c.h)), Offset(x, yAt(c.l)), strokeWidth = maxOf(1f, barW * 0.12f))
                val yTop = yAt(maxOf(c.o, c.c))
                val yBot = yAt(minOf(c.o, c.c))
                drawRect(col, Offset(x - barW * 0.35f, yTop), Size(barW * 0.7f, maxOf(1.5f, yBot - yTop)))
            }

            // ---- trend ribbon (on top of the candles)
            if (showRibbon && ribbon != null) {
                val m = ribbon.alma.size
                val from = maxOf(1, firstIdx)
                val to = minOf(lastIdx, m - 1)
                for (i in from..to) {
                    val a0 = ribbon.alma[i - 1]
                    val a1 = ribbon.alma[i]
                    if (a0.isNaN() || a1.isNaN()) continue
                    val tr = ribbon.trend[i]
                    val col = if (tr == 1) Brand.Green else if (tr == -1) Brand.Red else Brand.Muted
                    val e0 = ribbonEdge(ribbon, i - 1)
                    val e1 = ribbonEdge(ribbon, i)
                    val path = Path()
                    path.moveTo(xAt(i - 1), yAt(a0))
                    path.lineTo(xAt(i), yAt(a1))
                    path.lineTo(xAt(i), yAt(e1))
                    path.lineTo(xAt(i - 1), yAt(e0))
                    path.close()
                    drawPath(path, col.copy(alpha = 0.14f))
                    drawLine(col.copy(alpha = 0.9f), Offset(xAt(i - 1), yAt(e0)), Offset(xAt(i), yAt(e1)), strokeWidth = 3f)
                    drawLine(Color(0xFF9AA0AD), Offset(xAt(i - 1), yAt(a0)), Offset(xAt(i), yAt(a1)), strokeWidth = 1.2f)
                }
                val pos = ribbon.pos
                if (pos != null) {
                    val x0 = xAt(pos.entryIdx)
                    val x1 = if (pos.stopped) xAt(pos.stopIdx) else if (pos.endIdx >= 0) xAt(pos.endIdx) else pw
                    drawLine(Brand.Blue, Offset(x0, yAt(pos.entry)), Offset(x1, yAt(pos.entry)), strokeWidth = 2f, pathEffect = dash)
                    drawLine(Brand.Red, Offset(x0, yAt(pos.stop)), Offset(x1, yAt(pos.stop)), strokeWidth = 2f, pathEffect = dash)
                    label((if (pos.dir == 1) "LONG " else "SHORT ") + fp(pos.entry, dec), minOf(x1, pw) - 4f, yAt(pos.entry) - 4f, Brand.Blue.toArgb(), 10.sp.toPx(), alignRight = true)
                    label("SL -1R", minOf(x1, pw) - 4f, yAt(pos.stop) - 4f, Brand.Red.toArgb(), 10.sp.toPx(), alignRight = true)
                    for (k in pos.targets.indices) {
                        val hit = k < pos.hits
                        val y = yAt(pos.targets[k])
                        drawLine(Brand.Green.copy(alpha = if (hit) 0.45f else 0.9f), Offset(x0, y), Offset(x1, y), strokeWidth = 2f, pathEffect = dash)
                        label("T" + (k + 1) + " " + (k + 1) + "R" + (if (hit) " done" else ""), minOf(x1, pw) - 4f, y - 4f, Brand.GreenDark.toArgb(), 10.sp.toPx(), alignRight = true)
                    }
                }
            }

            // ---- current price line
            val lastC = cs[n - 1]
            val yp = yAt(lastC.c)
            drawLine(Brand.Muted.copy(alpha = 0.6f), Offset(0f, yp), Offset(pw, yp), strokeWidth = 1f, pathEffect = dots)
        }

        // price tag on the axis
        val lastC = cs[n - 1]
        val yp = yAt(lastC.c)
        if (yp >= 0f && yp <= ph) {
            val tagCol = if (lastC.c >= lastC.o) Brand.Green else Brand.Red
            drawRect(tagCol, Offset(pw, yp - 9.dp.toPx()), Size(axisW, 18.dp.toPx()))
            label(fp(lastC.c, dec), pw + 4f, yp + 4f, Color.White.toArgb(), 11.sp.toPx())
        }
    }
}
