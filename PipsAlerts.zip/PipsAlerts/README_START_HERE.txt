PIPSPROP ALERTS (version 1.0)

A phone app that watches Deriv and Binance markets in the background and sends price alerts from three strategies.

HOW TO BUILD (no Android Studio needed)
 1. Make a NEW, separate GitHub repository for this app (not the Pips Sender one).
 2. Upload PipsAlerts.zip (do not unzip it) and put build-apk.yml at .github/workflows/build-apk.yml.
 3. Open the Actions tab. "Build APK" starts by itself (or press Run workflow). About 5 to 8 minutes.
 4. A green tick: download PipsAlerts-debug-apk from Artifacts, unzip it, install app-debug.apk.
    A red cross: open the run, tap Summary, and send the lines that start with "e:".

STRATEGIES AND ALERTS
 * Trend Target Ribbon: new long/short signal, target hit, stop hit, price near a target, price near the trend line.
 * Isotropic Trend Lines: channel breakout, retest, failed breakout, direction change, price near the channel edge.
 * Market structure (from the PipsProp chart): price near support/resistance, a line broken, price leaving a range.
 Each alert type can be Off, Normal or Urgent (alarm sound, full screen on the lock screen, overrides Do Not Disturb).

PERMISSIONS (Settings tab shows the status of each)
 Notifications, battery "unrestricted", Do Not Disturb override, full-screen alerts, foreground service, wake lock,
 start after reboot, internet. On Tecno / Infinix / Itel phones also turn on Autostart for the app.

LICENSES AND HONESTY NOTES
 * Ribbon.kt is a Kotlin port of "Trend Target Ribbon [BOSWaves]" (c) BOSWaves, Mozilla Public License 2.0. That file stays
   under the MPL 2.0 (https://mozilla.org/MPL/2.0/); if you distribute the app, make the source of that file available.
 * Iso.kt is an APPROXIMATION written from the description in the header of the "Smart Trader, Episode 06" script. The
   original functions were not available, so its channels and signals can differ from TradingView. Check the license of the
   original before distributing it.
 * Stx.kt is a port of the STX engine from the PipsProp chart (otc-chart.js).
 * Alerts are information only, not trading advice. The app does not place trades.
 * This code has not been compiled by its author; expect to fix a few build errors on the first run.
